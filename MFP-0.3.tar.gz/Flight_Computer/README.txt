To install the Moore's Flight Computer onto your raspberry pi run the installer by entering in the comamnd line "./install.sh".
