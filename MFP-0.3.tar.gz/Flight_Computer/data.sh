#!/bin/bash
/etc/Moore_Flight_Computer/a.out &
disown
