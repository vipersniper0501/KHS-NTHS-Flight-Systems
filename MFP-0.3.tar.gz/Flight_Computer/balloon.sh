#!/bin/bash
chmod +x /etc/Moore_Flight_Computer/camera.sh
chmod +x /etc/Moore_Flight_Computer/data.sh
/etc/Moore_Flight_Computer/camera.sh &
disown
/etc/Moore_Flight_Computer/data.sh &
