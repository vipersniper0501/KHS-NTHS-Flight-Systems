#!/bin/bash
PICSDIR=/etc/Moore_Flight_Coomputer/Pictures
while true; do
	#DATE=`date +%Y%m%d`
	#HOUR=`date +%H%M%S`
	raspistill -o $PICSDIR/`date +%s`.jpg
	sleep 30
done
